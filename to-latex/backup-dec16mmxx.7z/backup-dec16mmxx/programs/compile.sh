#/bin/sh

gcc -o coefficients coefficients.c -lm
